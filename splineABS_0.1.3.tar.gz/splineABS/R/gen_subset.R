#' @title Generate sampling basis in each subset
#'
#' @description  The subsets is divied randomly and evenly. Return a list of indices of samples and indices basis in each subset.
#'
#' @param N             The number of whole smaples.
#' @param sample.index  The indices of samples. If it remains NULL, just return indices of each subset.
#' @param subset.number The number of subsets.
#' @param ratio         A vector of the ratio of size of each subset. Default is equal.
#'
#' @return       A list contains one or two vectors(depends on sample.index).
#'               1) The indices of sampling basis in each subset. (is sample.index != NULL)
#'               2) and indices of element in each subset.
#'
#' @examples
#' > generate.subset(N = 20, sample.index = c(1,3,5,11,13,15), subset.number = 2)
#' $subset.index
#' $subset.index[[1]]
#' [1]  1  4  5  6 10 11 13 14 15 16
#'
#' $subset.index[[2]]
#' [1]  2  3  7  8  9 12 17 18 19 20
#'
#' $subset.sample.index
#' $subset.sample.index[[1]]
#' [1]  1  5 11 13 15
#'
#' $subset.sample.index[[2]]
#' [1] 3
#' > generate.subset(10, subset.number = 2)
#' [[1]]
#' [1] 2 3 4 5 7
#'
#' [[2]]
#' [1]  1  6  8  9 10
#'
#' @export
#'
generate.subset <- function(N, sample.index=NULL, subset.number=1, ratio = NULL){

  whole.index <- 1:N
  subset.index <- list()
  subset.sample.index <- list()
  if(is.null(ratio)){
    # get a rough subset size
    subset.meansize <- round(N / subset.number)
    # get an exact subset size
    subset.size <- c( rep(subset.meansize, subset.number-1),
                      N-(subset.number-1)*subset.meansize )
  }else{
    # get a rough subset size
    subset.size <- round(N * ratio / sum(ratio))
    index.largest.subset <- which.max(ratio)
    # get an exact subset size (adjust the largest subset)
    subset.size[index.largest.subset] <- subset.size[index.largest.subset] -
      (sum(subset.size) - N)
  }


  remain.index <- whole.index

  for(i in 1:(subset.number)){

    if(i != subset.number){
      subset.index[[i]] <- sort(sample(remain.index, subset.size[i]))
      remain.index <- setdiff(remain.index, subset.index[[i]])
    }else{
      subset.index[[i]] <- sort(remain.index)
    }
    # generate indices of samples in each subset(if sample.index!=NULL)
    if(!is.null(sample.index)){
      subset.sample.index[[i]] <- intersect(sample.index, subset.index[[i]])
    }
  }

  if(is.null(sample.index)){
    return(subset.index)
  }else{
    return(list(subset.index=subset.index, subset.sample.index=subset.sample.index))
  }

}
